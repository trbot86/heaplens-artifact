"""Author-side retained-layout study; calls the published converter/sampler.

Native initial sampling: full retained Valkey log, independent disposable
copies, optional seed-only translation unit. EFRB: GUI stage only on p=1 DB.
Predicates measure visible layout evidence, not human diagnostic success.
"""
from __future__ import annotations
import argparse
import contextlib
import datetime
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import sqlite3
import subprocess
import sys
import time
import warnings

import numpy as np
import pandas as pd
sys.path.insert(0, '/root/sifter/sifter_vis_d3/server')
from sampler import Sampler

ROOT = Path('/root/sifter')
WORK = Path('/work')
EVIDENCE = Path('/evidence')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)

def live(frame, timestamp):
    return frame[(frame.allocTs <= timestamp) & (frame.freeTs.isna() | (frame.freeTs > timestamp))]

def qualifies(events, case, timestamp):
    events = [e for e in events if e['allocTs'] <= timestamp and
              (e.get('freeTs') is None or math.isnan(e['freeTs']) or e['freeTs'] > timestamp)]
    if case == 'valkey':
        objects = [e for e in events if e['type'] == 'robj' and e['size'] == 40 and e['addr'] == e['actualAddr']]
        return len(objects) >= 8 and any(e['addr'] % 64 + e['size'] > 64 for e in objects)
    nodes = {int(e['addr']) % 4096 // 64 for e in events
             if e['type'] == 'node_t' and e['size'] == 64 and e['addr'] % 64 == 0}
    infos = {int(e['addr']) % 4096 // 64 for e in events
             if e['type'] == 'info_t' and e['size'] == 64 and e['addr'] % 64 == 0}
    return (len(nodes) == 48 and len(infos) == 16 and not nodes.intersection(infos)
            and nodes.union(infos) == set(range(64))
            and len({slot % 4 for slot in infos}) == 1)

def make_reference(case, db, output):
    sampler = Sampler(str(db), num_buckets=2000)
    timestamp = sampler.min_ts + (2_000_000_000 if case == 'efrb' else int(.9 * (sampler.max_ts-sampler.min_ts)))
    objects = sampler.get_objects(sampler.all_data)
    objects = live(objects, timestamp).copy()
    objects['page'] = objects.addr // 4096
    good = [int(page) for page, group in objects.groupby('page')
            if qualifies(group.to_dict(orient='records'), case, timestamp)]
    assert good, f'No reference evidence for {case}'
    con = sqlite3.connect(f'file:{db}?mode=ro', uri=True)
    per_type = dict(con.execute("select TYPE,count(distinct ADDRESS/4096) from SUPERTABLE where TYPE != 'NULL' group by TYPE"))
    info = {'case':case, 'database':str(db), 'database_sha256':sha(db),
            'min_ts':sampler.min_ts, 'max_ts':sampler.max_ts, 'timestamp':timestamp,
            'total_pages':int(sampler.all_data.addr.floordiv(4096).nunique()),
            'qualifying_pages':good, 'distinct_pages_per_type':per_type,
            'live_objects':len(objects)}
    save(output, info)
    con.close()
    return info

def evaluate(case, db, reference, seed, pages_per_type, folder):
    random.seed(seed)
    np.random.seed(seed)
    start=time.monotonic()
    with (folder/'backend.log').open('x') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        warnings.simplefilter('always')
        sampler=Sampler(str(db), page_size=4096, cache_line_size=64, num_buckets=2000)
        retained = sorted(map(int, sampler.all_data.addr.floordiv(4096).unique()))
        per_type = {str(tp):int(n) for tp,n in sampler.all_data.groupby('type').addr.agg(lambda v: v.floordiv(4096).nunique()).items()}
        result=sampler.get_sample_of_pages(-1,-1,{tp:True for tp in sampler.types()},
                                           cluster_alg='mbkmeans', max_run_length=5,
                                           max_runs_from_cluster=3)
    good_raw = sorted(set(retained).intersection(reference['qualifying_pages']))
    good_display = [int(addr)//4096 for addr, data in result['page_num_events'].items()
                    if qualifies(data['events'],case,reference['timestamp'])]
    assert set(good_display).issubset(set(good_raw)), 'Display predicate differs from reference'
    violations = {tp:{'expected':min(pages_per_type,total),'observed':per_type.get(tp,0)}
                  for tp,total in reference['distinct_pages_per_type'].items()
                  if per_type.get(tp,0) < min(pages_per_type,total)}
    # Standard JSON encoder cannot serialize numpy integer scalars in all fields.
    import simplejson
    (folder/'representatives.json').write_text(simplejson.dumps(result,ignore_nan=True))
    report={'case':case,'seed':seed,'database_sha256':sha(db),
            'input_event_rows':len(sampler.all_data),'retained_pages':retained,
            'retained_qualifying_pages':good_raw,'displayed_qualifying_pages':good_display,
            'displayed_pages':[int(a)//4096 for a in result['page_num_events']],
            'cluster_count':int(result['num_clusters']), 'per_type_pages':per_type,
            'minimum_violations':violations,'backend_elapsed_seconds':time.monotonic()-start}
    save(folder/'result.json',report)
    return report

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--reps',type=int,default=20)
    parser.add_argument('--name',default='study')
    parser.add_argument('--resume', action='store_true')
    args=parser.parse_args()
    out=EVIDENCE/args.name
    out.mkdir(exist_ok=args.resume)
    runroot=WORK/args.name
    runroot.mkdir(exist_ok=args.resume)
    refs={}
    for case, db in [('valkey',WORK/'valkey-full/allocs.sqlite'),('efrb',ROOT/'sifter_vis_d3/efrb-smoke.sqlite')]:
        refpath=out/f'{case}-reference.json'
        if args.resume:
            refs[case]=json.loads(refpath.read_text())
            assert refs[case]['database_sha256']==sha(db)
        else:
            refs[case]=make_reference(case,db,refpath)
        gc.collect()
    command=['g++','-std=c++17', *map(str,sorted((ROOT/'type_analysis/convert_to_db').glob('*.cpp'))),
             '/author-tools/sampling_seed_hook.cpp','-g','-o',str(runroot/'convert-seeded'),'-lsqlite3','-lpthread','-ltbb']
    if not args.resume:
        subprocess.run(command,check=True)
    else:
        protocol=json.loads((out/'protocol.json').read_text())
        assert protocol['converter_sha256']==sha(runroot/'convert-seeded')
        assert protocol['sampler_sha256']==sha(ROOT/'sifter_vis_d3/server/sampler.py')
        save(out/'resume.json',{'reason':'GUI L2 resample exhausted shared test container memory; restarting sampling in its own network-isolated container',
             'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(__file__)})
    if not args.resume:
      save(out/'protocol.json',{'source_commit':'3b501479ac06b38b606a4dce544fda27cb739d0e',
         'build_command':command,'hook_sha256':sha('/author-tools/sampling_seed_hook.cpp'),
         'sampler_sha256':sha(ROOT/'sifter_vis_d3/server/sampler.py'),
         'converter_sha256':sha(runroot/'convert-seeded'), 'repetitions':args.reps,
         'gui':{'algorithm':'mbkmeans','buckets':2000,'page_size':4096,'line_size':64,'max_run_length':5,'max_runs_per_cluster':3},
         'predicates':{'valkey':'at least 8 live, unsplit 40-byte robj allocations on a page, at least one crossing a 64-byte cache-line boundary',
                       'efrb':'a complete page with 48 aligned 64-byte node_t allocations and 16 info_t allocations occupying every fourth line'},
         'scope':'Valkey full native initial sampling plus representative selection; EFRB representative selection of p=1 smoke trace only'})
    results=[]
    settings=[(.001,1),(.01,1),(.1,1),(.1,2)]
    for rep in range(args.reps):
        seed=20260928+rep
        for p,s in settings:
            label=f'valkey-p{p:g}-s{s}-r{rep:02d}'
            folder=out/label
            if args.resume and (folder/'trial.json').exists():
                record=json.loads((folder/'trial.json').read_text())
                assert record['seed']==seed and record['p']==p and record['s']==s
                assert record['database_sha256']==sha(runroot/label/'allocs.sqlite')
                results.append(record)
                continue
            if args.resume and folder.exists():
                # Preserve interrupted attempts in place, clearly separate from retries.
                folder.rename(out/(label+'-interrupted'))
                (runroot/label).rename(runroot/(label+'-interrupted'))
            folder.mkdir()
            work=runroot/label; work.mkdir()
            for name in ('binary_dump.txt','typeset_dump.txt','fileset_dump.txt'):
                shutil.copy2(WORK/'valkey-original'/name,work/name)
            env=dict(os.environ,HEAPLENS_TEST_SAMPLING_SEED=str(seed))
            cmd=[str(runroot/'convert-seeded'),'-s',str(p),'-t',str(s),'-b','3000']
            start=time.monotonic()
            with (folder/'converter.log').open('x') as log:
                subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
            record=evaluate('valkey',work/'allocs.sqlite',refs['valkey'],seed,s,folder)
            record.update(p=p,s=s,rep=rep,label=label,converter_command=cmd,total_seconds=time.monotonic()-start)
            results.append(record)
            save(folder/'trial.json',record)
            # Preserve independent input copies and databases until the study is audited.
            print(json.dumps({'trial':label,'retained':len(record['retained_pages']),
                  'good_raw':len(record['retained_qualifying_pages']),'good_display':len(record['displayed_qualifying_pages']),
                  'minimum_violations':len(record['minimum_violations']),'seconds':record['total_seconds']}),flush=True)
            gc.collect()
        folder=out/f'efrb-r{rep:02d}'
        if args.resume and (folder/'trial.json').exists():
            results.append(json.loads((folder/'trial.json').read_text()))
            continue
        folder.mkdir()
        record=evaluate('efrb',ROOT/'sifter_vis_d3/efrb-smoke.sqlite',refs['efrb'],seed,1,folder)
        record.update(p=1,s=1,rep=rep,label=folder.name)
        results.append(record);save(folder/'trial.json',record)
    save(out/'all-results.json',results)
    groups={}
    for rec in results:
        key=f"{rec['case']}-p{rec['p']:g}-s{rec['s']}"
        groups.setdefault(key,[]).append(rec)
    summary={key:{'trials':len(rows),'initial_success':sum(bool(r['retained_qualifying_pages']) for r in rows),
                  'display_success':sum(bool(r['displayed_qualifying_pages']) for r in rows),
                  'minimum_violation_trials':sum(bool(r['minimum_violations']) for r in rows),
                  'retained_pages_range':[min(len(r['retained_pages']) for r in rows),max(len(r['retained_pages']) for r in rows)],
                  'displayed_pages_range':[min(len(r['displayed_pages']) for r in rows),max(len(r['displayed_pages']) for r in rows)]}
             for key,rows in groups.items()}
    save(out/'summary.json',summary)
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    main()
