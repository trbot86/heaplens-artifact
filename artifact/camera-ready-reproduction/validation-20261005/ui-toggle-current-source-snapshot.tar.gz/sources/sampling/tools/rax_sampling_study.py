"""Frozen-criterion author study; production source and prior evidence read-only."""
import collections
import gc
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time

sys.path.insert(0, '/author-tools')
import sampling_layout_study as study

OUT = Path('/evidence')
WORK = Path('/work')
ROOT = Path('/root/sifter')
PRIOR = Path('/prior-corrected')
OLD = Path('/prior-original')
FULL = Path('/retained/valkey-full/allocs.sqlite')
COLS = 'FILE,LINE,TIMESTAMP,SIZE,ACTUALADDR,ADDRESS,isNew,TYPE'


def load(p):
    return json.loads(Path(p).read_text())


def identity(e):
    return int(e['addr']), int(e['allocTs']), int(e['size'])


def score(result, payload, reference):
    stamp = reference['timestamp']
    targets = {identity(e) for e in reference['crossing_objects']}
    targetpages = set(reference['crossing_pages'])
    retained = set(result['retained_pages'])
    displayed = {int(addr)//4096 for addr in payload['page_num_events']}
    good = set()
    apparent = set()
    for page, data in payload['page_num_events'].items():
        for e in data['events']:
            if e['type'] != 'raxNode' or e['addr'] != e['actualAddr']:
                continue
            if not (0 < e['size'] <= 64 and e['addr'] % 64 + e['size'] > 64):
                continue
            if e['allocTs'] > stamp or (e['freeTs'] is not None and e['freeTs'] <= stamp):
                continue
            key = identity(e)
            apparent.add(key)
            if key in targets:
                good.add(key)
                assert int(page)//4096 == key[0]//4096
    rawpages = targetpages & retained
    assert {k[0]//4096 for k in good} <= rawpages
    return dict(initial_success=bool(rawpages), display_success=bool(good),
                retained_pages=len(retained), displayed_pages=len(displayed),
                retained_target_pages=sorted(rawpages),
                retained_target_objects=sum(k[0]//4096 in retained for k in targets),
                selected_target_pages=sorted(displayed & targetpages),
                displayed_target_pages=sorted({k[0]//4096 for k in good}),
                displayed_target_objects=sorted(good),
                displayed_unverified_crossing_identities=sorted(apparent-targets),
                selected_target_pages_without_valid_evidence=sorted((displayed&targetpages)-{k[0]//4096 for k in good}),
                original_robj_success=bool(result['displayed_qualifying_pages']),
                minimum_violations=result['minimum_violations'])


def selftest():
    ref = {'timestamp':100, 'crossing_pages':[1], 'crossing_objects':[
        {'addr':4096+56, 'allocTs':10, 'size':24}]}
    result = {'retained_pages':[1], 'displayed_qualifying_pages':[], 'minimum_violations':{}}
    valid = dict(addr=4152, actualAddr=4152, allocTs=10, freeTs=None, size=24, type='raxNode')
    def run(events):
        return score(result, {'page_num_events':{'4096':{'events':events}}}, ref)
    assert run([valid])['display_success']
    assert not run([dict(valid, allocTs=9)])['display_success']
    assert not run([dict(valid, freeTs=100)])['display_success']
    assert not run([dict(valid, actualAddr=4000)])['display_success']
    assert not run([dict(valid, type='void')])['display_success']
    assert not run([])['display_success']
    assert len(run([valid, valid])['displayed_target_objects']) == 1


def summarize(records):
    groups = collections.defaultdict(list)
    for row in records:
        groups[f"p{row['p']:g}-s{row['s']}"].append(row)
    return {key:dict(trials=len(rows),
        initial_success=sum(r['initial_success'] for r in rows),
        display_success=sum(r['display_success'] for r in rows),
        initial_success_but_display_failure=sum(r['initial_success'] and not r['display_success'] for r in rows),
        minimum_violation_trials=sum(bool(r['minimum_violations']) for r in rows),
        retained_pages_range=[min(r['retained_pages'] for r in rows),max(r['retained_pages'] for r in rows)],
        displayed_pages_range=[min(r['displayed_pages'] for r in rows),max(r['displayed_pages'] for r in rows)],
        displayed_target_objects_range=[min(len(r['displayed_target_objects']) for r in rows),max(len(r['displayed_target_objects']) for r in rows)],
        unverified_crossing_payload_trials=sum(bool(r['displayed_unverified_crossing_identities']) for r in rows),
        original_robj_success=sum(r['original_robj_success'] for r in rows)) for key,rows in groups.items()}


def main():
    selftest()
    reference = load(OUT/'lifetime-audit.json')
    prior = load(PRIOR/'summary.json')
    for path, sha in prior['source_sha256'].items():
        assert study.sha(ROOT/path)==sha, f'Source drift: {path}'
    study.save(OUT/'execution-protocol.json', dict(protocol_sha256=study.sha(OUT/'PROTOCOL.md'),
        script_sha256=study.sha(__file__), audit_sha256=study.sha('/author-tools/audit_rax_lifetimes.py'),
        source_sha256=prior['source_sha256'], binary_log_sha256=study.sha('/retained/valkey-original/binary_dump.txt'),
        complete_database_sha256=study.sha(FULL), python=sys.version,
        libraries={name:__import__(name).__version__ for name in ['numpy','pandas','sklearn']}))
    historical=[]
    for folder in sorted(OLD.glob('valkey-p*-r[0-9][0-9]')):
        row=load(folder/'trial.json')
        historical.append(dict(p=row['p'],s=row['s'],seed=row['seed'],label=folder.name,
            **score(row,load(folder/'representatives.json'),reference)))
    assert len(historical)==80
    study.save(OUT/'historical-results.json',historical)
    study.save(OUT/'historical-summary.json',summarize(historical))
    print('Historical audit: '+json.dumps(summarize(historical)),flush=True)
    original_ref=load(PRIOR/'reference.json')
    assert original_ref['database_sha256']==study.sha(FULL)
    with sqlite3.connect(f'file:{FULL}?mode=ro', uri=True) as db:
        full=collections.defaultdict(collections.Counter)
        for row in db.execute('select '+COLS+' from SUPERTABLE'):
            full[row[5]//4096][row]+=1
    converter=WORK/'convert'
    subprocess.run(['g++','-std=c++17','-O1',*map(str,sorted((ROOT/'type_analysis/convert_to_db').glob('*.cpp'))),
                    '-lsqlite3','-lpthread','-ltbb','-o',str(converter)],check=True)
    study.save(OUT/'build.json',dict(converter_sha256=study.sha(converter)))
    reuse={(r['p'],r['s'],r['seed']):i for i,r in enumerate(prior['native_runs'])}
    results=[]
    for p,s in [(.001,1),(.01,1),(.1,1),(.1,2),(1.,1)]:
      for rep in range(20):
        seed=20260928+rep
        label=f'p{p:g}-s{s}-r{rep:02d}'
        start=time.monotonic()
        folder=OUT/label
        folder.mkdir()
        work=WORK/label
        work.mkdir()
        if (p,s,seed) in reuse:
            index=reuse[p,s,seed]
            previous=PRIOR/str(index)
            raw=load(previous/'result.json')
            database=Path('/prior-databases')/str(index)/'allocs.sqlite'
            assert raw['database_sha256']==study.sha(database)
            assert raw['seed']==seed
            payload=load(previous/'representatives.json')
            source=dict(reused_trial=str(previous), payload_sha256=study.sha(previous/'representatives.json'))
        else:
            if p<1:
                for name in ('binary_dump.txt','typeset_dump.txt','fileset_dump.txt'):
                    shutil.copyfile(Path('/retained/valkey-original')/name,work/name)
                command=[str(converter),'--sample',str(p),'--num-pages-per-type',str(s),
                         '--seed',str(seed),'--num-buckets','3000']
                with (folder/'converter.log').open('x') as log:
                    subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
                assert study.sha(work/'binary_dump.txt')==study.sha('/retained/valkey-original/binary_dump.txt')
                database=work/'allocs.sqlite'
            else:
                database=FULL
            raw=study.evaluate('valkey',database,original_ref,seed,s,folder)
            payload=load(folder/'representatives.json')
            source=dict(reused_trial=None,payload_sha256=study.sha(folder/'representatives.json'))
        # Verify every retained page includes the full reference event multiset.
        observed=collections.defaultdict(collections.Counter)
        with sqlite3.connect(f'file:{database}?mode=ro', uri=True) as db:
            for row in db.execute('select '+COLS+' from SUPERTABLE'):
                observed[row[5]//4096][row]+=1
        assert all(rows==full[page] for page,rows in observed.items())
        assert set(observed)==set(raw['retained_pages'])
        assert not raw['minimum_violations']
        result=dict(p=p,s=s,seed=seed,label=label,source=source,database_sha256=study.sha(database),
            complete_page_histories=True, **score(raw,payload,reference))
        results.append(result)
        study.save(folder/'rax-result.json',result)
        print(json.dumps(dict(trial=label,initial=result['initial_success'],display=result['display_success'],
            pages=result['retained_pages'],target_objects=len(result['displayed_target_objects']),
            reused=source['reused_trial'] is not None,seconds=round(time.monotonic()-start,2))),flush=True)
        del observed,payload,raw
        gc.collect()
    study.save(OUT/'current-results.json',results)
    study.save(OUT/'current-summary.json',summarize(results))
    print('Current summary: '+json.dumps(summarize(results)),flush=True)


if __name__=='__main__':
    main()
